#include "programa.h"


int main(){

    Suma sumar;
    sumar.listar();
    sumar.ejecutar();

    CuentaAtras contar;
    contar.listar();
    contar.ejecutar();

    Factorial fact;
    fact.listar();
    fact.ejecutar();
}