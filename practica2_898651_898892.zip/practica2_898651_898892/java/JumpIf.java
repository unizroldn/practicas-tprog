import java.util.Stack;

public class JumpIf extends Instruccion{
    private int constante;
    public JumpIf(int valor){
        constante = valor;
    }
    @Override
    public void ejecutar(Stack<Integer> pila, int[] pc){

        int cima=pila.pop();
        if (cima>=0){
            pc[0]=constante;
        }else{
            pc[0]++;
        }
    }
    @Override
    public String listar(){
        return "Jumpif " + constante + " \n";
    }
}