import java.util.Stack;

public class Push extends Instruccion{
    private int constante;
    public Push(int valor){
        constante = valor;
    }
    @Override
    public void ejecutar(Stack<Integer> pila, int[] pc){

        pila.push(constante);
        pc[0]++;
    }
    @Override
    public String listar(){
        return "push " + constante + "\n";
    }
}